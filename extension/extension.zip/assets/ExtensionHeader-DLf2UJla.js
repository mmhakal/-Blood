import{c as n,i as c,j as t}from"./Badge-CsQEgibA.js";import{c as p,a as h}from"./authService-BgRBnebg.js";/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]],x=n("Activity",g);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],L=n("ChevronRight",y);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]],b=n("ExternalLink",u);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]],_=n("FileText",v);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=[["path",{d:"M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2",key:"18mbvz"}],["path",{d:"M6.453 15h11.094",key:"3shlmq"}],["path",{d:"M8.5 2h7",key:"csnxdl"}]],M=n("FlaskConical",k);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]],R=n("Search",m);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],j=n("Settings",f);class C{getAppBaseUrl(){return p.getConfig().appBaseUrl}async openWebApp(e="/"){await h.isAuthenticated();const i=e.startsWith("/")?e:`/${e}`,a=`${this.getAppBaseUrl()}${i}`;typeof chrome<"u"&&chrome?.tabs?.create?chrome.tabs.create({url:a}):window.open(a,"_blank")}openPatient(e){return this.openWebApp(`/patients?id=${encodeURIComponent(e)}`)}openOrder(e){return this.openWebApp(`/orders?id=${encodeURIComponent(e)}`)}openReport(e){return this.openWebApp(`/reports?id=${encodeURIComponent(e)}`)}openInvoice(e){return this.openWebApp(`/billing?invoiceId=${encodeURIComponent(e)}`)}openSample(e){return this.openWebApp(`/samples?id=${encodeURIComponent(e)}`)}}const I=new C,$=({session:o,onOpenSettings:e,onOpenSidepanel:i,title:a="MediFlow LIS"})=>{const r=navigator.onLine,s=c.getLanguage(),l=()=>{const d=s==="en"?"hi":"en";c.setLanguage(d)};return t.jsxs("header",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 14px",borderBottom:"1px solid var(--border-color)",background:"var(--bg-glass)",backdropFilter:"blur(8px)",position:"sticky",top:0,zIndex:100},children:[t.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[t.jsx("div",{style:{width:26,height:26,borderRadius:7,background:"linear-gradient(135deg, #0284c7 0%, #0369a1 100%)",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",boxShadow:"0 2px 5px rgba(2, 132, 199, 0.3)"},children:t.jsx(x,{size:15})}),t.jsxs("div",{children:[t.jsx("div",{style:{fontSize:13,fontWeight:800,color:"var(--text-primary)",letterSpacing:"-0.01em"},children:a}),o?.activeBranchName&&t.jsx("div",{style:{fontSize:10,color:"var(--primary)",fontWeight:600},children:o.activeBranchName})]})]}),t.jsxs("div",{style:{display:"flex",alignItems:"center",gap:6},children:[t.jsx("div",{title:r?"LIS Online":"Offline",style:{width:8,height:8,borderRadius:"50%",backgroundColor:r?"var(--success)":"var(--danger)",boxShadow:r?"0 0 6px var(--success)":"none"}}),t.jsx("button",{onClick:l,title:"Switch Language (EN / HI)",style:{background:"transparent",border:"none",fontSize:11,fontWeight:700,color:"var(--text-secondary)",cursor:"pointer",padding:"2px 5px",borderRadius:4},children:s.toUpperCase()}),t.jsx("button",{onClick:()=>I.openWebApp(),title:"Launch Full LIS Web App",style:{background:"transparent",border:"none",color:"var(--text-secondary)",cursor:"pointer",display:"flex",padding:4,borderRadius:4},children:t.jsx(b,{size:15})}),e&&t.jsx("button",{onClick:e,title:"Options & Settings",style:{background:"transparent",border:"none",color:"var(--text-secondary)",cursor:"pointer",display:"flex",padding:4,borderRadius:4},children:t.jsx(j,{size:15})})]})]})};export{L as C,$ as E,M as F,R as S,_ as a,b,I as l};
